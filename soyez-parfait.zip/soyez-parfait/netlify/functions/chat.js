// ============================================================
// /api/chat/* : chat global, temps réel simulé par sondage (polling)
// ============================================================
const { sql } = require('./lib/db');
const { getAuthUser } = require('./lib/auth');
const { json } = require('./lib/response');
const { saveMediaBase64, mediaTypeFromContentType } = require('./lib/blobs');

function subpath(event) {
  return event.path.replace(/^\/\.netlify\/functions\/chat/, '') || '/';
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, {});

  const authUser = getAuthUser(event);
  if (!authUser) return json(401, { error: 'Authentification requise.' });

  const path = subpath(event);
  const method = event.httpMethod;
  const qs = event.queryStringParameters || {};

  try {
    // ---- GET / : historique complet, ou nouveaux messages depuis ?since= ----
    if (path === '/' && method === 'GET') {
      const since = qs.since;
      let rows;

      if (since) {
        rows = await sql`
          SELECT username, content, media_url, media_type, created_at
          FROM messages WHERE created_at > ${since}
          ORDER BY created_at ASC LIMIT 200`;
      } else {
        rows = await sql`
          SELECT username, content, media_url, media_type, created_at
          FROM messages ORDER BY created_at DESC LIMIT 50`;
        rows.reverse();
      }
      return json(200, rows);
    }

    // ---- POST / : envoyer un message ----
    if (path === '/' && method === 'POST') {
      const { content, mediaBase64, mediaContentType } = JSON.parse(event.body || '{}');
      const text = (content || '').trim().slice(0, 2000);

      let mediaUrl = null;
      let mediaType = null;
      if (mediaBase64 && mediaContentType) {
        mediaUrl = await saveMediaBase64(mediaBase64, mediaContentType, `chat-${authUser.id}`);
        mediaType = mediaTypeFromContentType(mediaContentType);
      }

      if (!text && !mediaUrl) return json(400, { error: 'Message vide.' });

      await sql`
        INSERT INTO messages (user_id, username, content, media_url, media_type)
        VALUES (${authUser.id}, ${authUser.username}, ${text}, ${mediaUrl}, ${mediaType})`;

      return json(201, {
        username: authUser.username,
        content: text,
        media_url: mediaUrl,
        media_type: mediaType,
        created_at: new Date().toISOString(),
      });
    }

    return json(404, { error: 'Route inconnue.' });
  } catch (err) {
    console.error(err);
    return json(500, { error: err.message || 'Erreur serveur.' });
  }
};
