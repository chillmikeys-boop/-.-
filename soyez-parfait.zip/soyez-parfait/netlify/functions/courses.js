// ============================================================
// /api/courses/* : cours, exercices, soumissions, classement
// ============================================================
const { sql } = require('./lib/db');
const { getAuthUser } = require('./lib/auth');
const { json } = require('./lib/response');

function subpath(event) {
  return event.path.replace(/^\/\.netlify\/functions\/courses/, '') || '/';
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, {});

  const authUser = getAuthUser(event);
  if (!authUser) return json(401, { error: 'Authentification requise.' });

  const path = subpath(event);
  const method = event.httpMethod;

  try {
    // ---- GET / : liste des cours + progression ----
    if (path === '/' && method === 'GET') {
      const courses = await sql`SELECT * FROM courses ORDER BY position ASC`;
      const progress = await sql`
        SELECT e.course_id, COUNT(*) FILTER (WHERE p.status = 'termine') AS termines, COUNT(*) AS total
        FROM exercises e
        LEFT JOIN progress p ON p.exercise_id = e.id AND p.user_id = ${authUser.id}
        GROUP BY e.course_id`;

      const progressMap = {};
      progress.forEach((r) => {
        progressMap[r.course_id] = { termines: parseInt(r.termines, 10), total: parseInt(r.total, 10) };
      });

      const result = courses.map((c) => ({ ...c, progress: progressMap[c.id] || { termines: 0, total: 0 } }));
      return json(200, result);
    }

    // ---- GET /leaderboard/top ----
    if (path === '/leaderboard/top' && method === 'GET') {
      const rows = await sql`
        SELECT u.username, s.total_points FROM scores s
        JOIN users u ON u.id = s.user_id
        ORDER BY s.total_points DESC LIMIT 20`;
      return json(200, rows);
    }

    // ---- GET /:id/exercises ----
    const exMatch = path.match(/^\/(\d+)\/exercises$/);
    if (exMatch && method === 'GET') {
      const courseId = exMatch[1];
      const rows = await sql`
        SELECT e.*, p.status, p.score, p.submitted_code
        FROM exercises e
        LEFT JOIN progress p ON p.exercise_id = e.id AND p.user_id = ${authUser.id}
        WHERE e.course_id = ${courseId}
        ORDER BY e.position ASC`;
      return json(200, rows);
    }

    // ---- POST /exercises/:id/submit ----
    const subMatch = path.match(/^\/exercises\/(\d+)\/submit$/);
    if (subMatch && method === 'POST') {
      const exerciseId = subMatch[1];
      const { code, output } = JSON.parse(event.body || '{}');

      const exRows = await sql`SELECT * FROM exercises WHERE id = ${exerciseId}`;
      const exercise = exRows[0];
      if (!exercise) return json(404, { error: 'Exercice introuvable.' });

      const isCorrect = !!(output && output.trim() === (exercise.expected_output || '').trim());
      const status = isCorrect ? 'termine' : 'en_cours';
      const score = isCorrect ? exercise.points : 0;
      const completedAt = isCorrect ? new Date().toISOString() : null;

      await sql`
        INSERT INTO progress (user_id, exercise_id, status, score, submitted_code, completed_at)
        VALUES (${authUser.id}, ${exerciseId}, ${status}, ${score}, ${code}, ${completedAt})
        ON CONFLICT (user_id, exercise_id)
        DO UPDATE SET status = ${status}, score = ${score}, submitted_code = ${code}, completed_at = ${completedAt}`;

      if (isCorrect) {
        await sql`
          INSERT INTO scores (user_id, total_points) VALUES (${authUser.id}, ${score})
          ON CONFLICT (user_id) DO UPDATE SET total_points = scores.total_points + ${score}, updated_at = NOW()`;
      }

      return json(200, { correct: isCorrect, score });
    }

    return json(404, { error: 'Route inconnue.' });
  } catch (err) {
    console.error(err);
    return json(500, { error: err.message || 'Erreur serveur.' });
  }
};
