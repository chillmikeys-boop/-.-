// ============================================================
// /api/messages/* : discussions privées (liste, historique, envoi)
// Le temps réel est assuré par sondage (polling) côté frontend,
// puisque les fonctions Netlify ne maintiennent pas de connexion
// persistante comme un WebSocket.
// ============================================================
const { sql } = require('./lib/db');
const { getAuthUser } = require('./lib/auth');
const { json } = require('./lib/response');
const { saveMediaBase64, mediaTypeFromContentType } = require('./lib/blobs');

function subpath(event) {
  return event.path.replace(/^\/\.netlify\/functions\/messages/, '') || '/';
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, {});

  const authUser = getAuthUser(event);
  if (!authUser) return json(401, { error: 'Authentification requise.' });

  const path = subpath(event);
  const method = event.httpMethod;
  const qs = event.queryStringParameters || {};

  try {
    // ---- GET /users : liste des utilisateurs pour démarrer une discussion ----
    if (path === '/users' && method === 'GET') {
      const rows = await sql`
        SELECT id, username, avatar_url FROM users WHERE id != ${authUser.id} ORDER BY username ASC`;
      return json(200, rows);
    }

    // ---- GET /conversations : liste des conversations existantes ----
    if (path === '/conversations' && method === 'GET') {
      const rows = await sql`
        SELECT
          u.id AS user_id, u.username, u.avatar_url,
          (SELECT content FROM private_messages
             WHERE (sender_id = ${authUser.id} AND receiver_id = u.id) OR (sender_id = u.id AND receiver_id = ${authUser.id})
             ORDER BY created_at DESC LIMIT 1) AS last_message,
          (SELECT created_at FROM private_messages
             WHERE (sender_id = ${authUser.id} AND receiver_id = u.id) OR (sender_id = u.id AND receiver_id = ${authUser.id})
             ORDER BY created_at DESC LIMIT 1) AS last_time,
          (SELECT COUNT(*) FROM private_messages
             WHERE sender_id = u.id AND receiver_id = ${authUser.id} AND read_at IS NULL) AS unread
        FROM users u
        WHERE u.id != ${authUser.id}
          AND EXISTS (
            SELECT 1 FROM private_messages
            WHERE (sender_id = ${authUser.id} AND receiver_id = u.id) OR (sender_id = u.id AND receiver_id = ${authUser.id})
          )
        ORDER BY last_time DESC NULLS LAST`;
      return json(200, rows);
    }

    // ---- GET /:userId : historique (avec ?since= pour le sondage incrémental) ----
    const convMatch = path.match(/^\/(\d+)$/);
    if (convMatch && method === 'GET') {
      const otherId = convMatch[1];
      const since = qs.since;

      let rows;
      if (since) {
        rows = await sql`
          SELECT * FROM private_messages
          WHERE ((sender_id = ${authUser.id} AND receiver_id = ${otherId}) OR (sender_id = ${otherId} AND receiver_id = ${authUser.id}))
            AND created_at > ${since}
          ORDER BY created_at ASC LIMIT 200`;
      } else {
        rows = await sql`
          SELECT * FROM private_messages
          WHERE (sender_id = ${authUser.id} AND receiver_id = ${otherId}) OR (sender_id = ${otherId} AND receiver_id = ${authUser.id})
          ORDER BY created_at ASC LIMIT 200`;
        await sql`
          UPDATE private_messages SET read_at = NOW()
          WHERE sender_id = ${otherId} AND receiver_id = ${authUser.id} AND read_at IS NULL`;
      }
      return json(200, rows);
    }

    // ---- POST /:userId : envoyer un message privé ----
    if (convMatch && method === 'POST') {
      const receiverId = convMatch[1];
      const { content, mediaBase64, mediaContentType } = JSON.parse(event.body || '{}');
      const text = (content || '').trim();

      let mediaUrl = null;
      let mediaType = null;
      if (mediaBase64 && mediaContentType) {
        mediaUrl = await saveMediaBase64(mediaBase64, mediaContentType, `dm-${authUser.id}`);
        mediaType = mediaTypeFromContentType(mediaContentType);
      }

      if (!text && !mediaUrl) return json(400, { error: 'Message vide.' });

      const rows = await sql`
        INSERT INTO private_messages (sender_id, receiver_id, content, media_url, media_type)
        VALUES (${authUser.id}, ${receiverId}, ${text}, ${mediaUrl}, ${mediaType})
        RETURNING *`;
      return json(201, rows[0]);
    }

    return json(404, { error: 'Route inconnue.' });
  } catch (err) {
    console.error(err);
    return json(500, { error: err.message || 'Erreur serveur.' });
  }
};
