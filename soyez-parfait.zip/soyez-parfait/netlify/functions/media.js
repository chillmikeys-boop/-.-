// ============================================================
// /api/media/:key : sert un fichier (avatar, image, vidéo)
// stocké dans Netlify Blobs.
// ============================================================
const { getStore } = require('@netlify/blobs');
const { json } = require('./lib/response');

function subpath(event) {
  return event.path.replace(/^\/\.netlify\/functions\/media/, '').replace(/^\//, '');
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, {});
  if (event.httpMethod !== 'GET') return json(405, { error: 'Méthode non autorisée.' });

  const key = subpath(event);
  if (!key) return json(400, { error: 'Clé manquante.' });

  try {
    const store = getStore('media');
    const result = await store.getWithMetadata(key, { type: 'arrayBuffer' });

    if (!result) return json(404, { error: 'Média introuvable.' });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': result.metadata?.contentType || 'application/octet-stream',
        'Cache-Control': 'public, max-age=31536000, immutable',
        'Access-Control-Allow-Origin': '*',
      },
      body: Buffer.from(result.data).toString('base64'),
      isBase64Encoded: true,
    };
  } catch (err) {
    console.error(err);
    return json(500, { error: 'Erreur serveur.' });
  }
};
