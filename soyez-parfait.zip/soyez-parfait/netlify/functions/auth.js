// ============================================================
// /api/auth/* : inscription, connexion, profil, photo de profil
// ============================================================
const bcrypt = require('bcryptjs');
const { sql } = require('./lib/db');
const { sign, getAuthUser } = require('./lib/auth');
const { json } = require('./lib/response');
const { saveMediaBase64 } = require('./lib/blobs');

function subpath(event) {
  return event.path.replace(/^\/\.netlify\/functions\/auth/, '') || '/';
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, {});

  const path = subpath(event);
  const method = event.httpMethod;

  try {
    // ---- POST /register ----
    if (path === '/register' && method === 'POST') {
      const { username, email, password } = JSON.parse(event.body || '{}');
      if (!username || !email || !password) return json(400, { error: 'Champs manquants.' });

      const existing = await sql`SELECT id FROM users WHERE username = ${username} OR email = ${email}`;
      if (existing.length > 0) return json(409, { error: 'Utilisateur ou email déjà utilisé.' });

      const hash = await bcrypt.hash(password, 10);
      const rows = await sql`
        INSERT INTO users (username, email, password_hash)
        VALUES (${username}, ${email}, ${hash})
        RETURNING id, username, email, role, avatar_url`;

      const user = rows[0];
      const token = sign(user);
      return json(201, { user, token });
    }

    // ---- POST /login ----
    if (path === '/login' && method === 'POST') {
      const { username, password } = JSON.parse(event.body || '{}');
      if (!username || !password) return json(400, { error: 'Champs manquants.' });

      const rows = await sql`SELECT * FROM users WHERE username = ${username} OR email = ${username}`;
      const user = rows[0];
      if (!user) return json(401, { error: 'Identifiants invalides.' });

      const valid = await bcrypt.compare(password, user.password_hash);
      if (!valid) return json(401, { error: 'Identifiants invalides.' });

      const token = sign(user);
      return json(200, {
        user: { id: user.id, username: user.username, email: user.email, role: user.role, avatar_url: user.avatar_url },
        token,
      });
    }

    // ---- GET /me ----
    if (path === '/me' && method === 'GET') {
      const authUser = getAuthUser(event);
      if (!authUser) return json(401, { error: 'Authentification requise.' });

      const rows = await sql`SELECT id, username, email, role, avatar_url FROM users WHERE id = ${authUser.id}`;
      return json(200, rows[0] || {});
    }

    // ---- POST /avatar ----
    if (path === '/avatar' && method === 'POST') {
      const authUser = getAuthUser(event);
      if (!authUser) return json(401, { error: 'Authentification requise.' });

      const { dataBase64, contentType } = JSON.parse(event.body || '{}');
      if (!dataBase64 || !contentType) return json(400, { error: 'Image manquante.' });

      const avatarUrl = await saveMediaBase64(dataBase64, contentType, `avatar-${authUser.id}`);
      await sql`UPDATE users SET avatar_url = ${avatarUrl} WHERE id = ${authUser.id}`;

      return json(200, { avatar_url: avatarUrl });
    }

    return json(404, { error: 'Route inconnue.' });
  } catch (err) {
    console.error(err);
    return json(500, { error: err.message || 'Erreur serveur.' });
  }
};
