// ============================================================
// /api/posts/* : fil de publications (texte + médias, likes)
// ============================================================
const { sql } = require('./lib/db');
const { getAuthUser } = require('./lib/auth');
const { json } = require('./lib/response');
const { saveMediaBase64, mediaTypeFromContentType } = require('./lib/blobs');

function subpath(event) {
  return event.path.replace(/^\/\.netlify\/functions\/posts/, '') || '/';
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, {});

  const authUser = getAuthUser(event);
  if (!authUser) return json(401, { error: 'Authentification requise.' });

  const path = subpath(event);
  const method = event.httpMethod;

  try {
    // ---- GET / : fil d'actualité ----
    if (path === '/' && method === 'GET') {
      const rows = await sql`
        SELECT p.*, u.username, u.avatar_url,
               COUNT(l.id) AS likes_count,
               EXISTS(SELECT 1 FROM post_likes WHERE post_id = p.id AND user_id = ${authUser.id}) AS liked_by_me
        FROM posts p
        JOIN users u ON u.id = p.user_id
        LEFT JOIN post_likes l ON l.post_id = p.id
        GROUP BY p.id, u.username, u.avatar_url
        ORDER BY p.created_at DESC
        LIMIT 100`;
      return json(200, rows);
    }

    // ---- POST / : créer une publication ----
    if (path === '/' && method === 'POST') {
      const { content, mediaBase64, mediaContentType } = JSON.parse(event.body || '{}');
      const text = (content || '').trim();

      let mediaUrl = null;
      let mediaType = null;
      if (mediaBase64 && mediaContentType) {
        mediaUrl = await saveMediaBase64(mediaBase64, mediaContentType, `post-${authUser.id}`);
        mediaType = mediaTypeFromContentType(mediaContentType);
      }

      if (!text && !mediaUrl) return json(400, { error: 'Ajoute du texte ou un média.' });

      const rows = await sql`
        INSERT INTO posts (user_id, content, media_url, media_type)
        VALUES (${authUser.id}, ${text}, ${mediaUrl}, ${mediaType})
        RETURNING *`;

      const post = rows[0];
      post.username = authUser.username;
      post.likes_count = 0;
      post.liked_by_me = false;
      return json(201, post);
    }

    // ---- POST /:id/like ----
    const likeMatch = path.match(/^\/(\d+)\/like$/);
    if (likeMatch && method === 'POST') {
      const postId = likeMatch[1];
      const existing = await sql`SELECT id FROM post_likes WHERE post_id = ${postId} AND user_id = ${authUser.id}`;

      if (existing.length > 0) {
        await sql`DELETE FROM post_likes WHERE post_id = ${postId} AND user_id = ${authUser.id}`;
        return json(200, { liked: false });
      } else {
        await sql`INSERT INTO post_likes (post_id, user_id) VALUES (${postId}, ${authUser.id})`;
        return json(200, { liked: true });
      }
    }

    // ---- DELETE /:id ----
    const idMatch = path.match(/^\/(\d+)$/);
    if (idMatch && method === 'DELETE') {
      const postId = idMatch[1];
      const rows = await sql`SELECT user_id FROM posts WHERE id = ${postId}`;
      if (rows.length === 0) return json(404, { error: 'Publication introuvable.' });
      if (rows[0].user_id !== authUser.id) return json(403, { error: 'Non autorisé.' });

      await sql`DELETE FROM posts WHERE id = ${postId}`;
      return json(200, { deleted: true });
    }

    return json(404, { error: 'Route inconnue.' });
  } catch (err) {
    console.error(err);
    return json(500, { error: err.message || 'Erreur serveur.' });
  }
};
