// ============================================================
// Chat global : temps réel simulé par sondage (polling) toutes
// les 3 secondes, puisque les Netlify Functions ne maintiennent
// pas de connexion WebSocket persistante.
// ============================================================
const Chat = {
  selectedFile: null,
  pollInterval: null,
  lastTimestamp: null,

  init() {
    document.getElementById('chat-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this.sendMessage();
    });

    const attachBtn = document.getElementById('chat-attach-btn');
    const fileInput = document.getElementById('chat-media-input');
    attachBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', () => {
      this.selectedFile = fileInput.files[0] || null;
      attachBtn.classList.toggle('has-file', !!this.selectedFile);
    });
  },

  async connect() {
    // Charge l'historique initial puis démarre le sondage
    try {
      const history = await Api.getChatMessages();
      history.forEach((m) => this.renderMessage(m));
      if (history.length > 0) this.lastTimestamp = history[history.length - 1].created_at;
    } catch (err) {
      console.warn('Chat : chargement initial impossible', err.message);
    }

    this.startPolling();
  },

  startPolling() {
    if (this.pollInterval) clearInterval(this.pollInterval);
    this.pollInterval = setInterval(() => this.poll(), 3000);
  },

  async poll() {
    try {
      const newMessages = await Api.getChatMessages(this.lastTimestamp);
      newMessages.forEach((m) => this.renderMessage(m));
      if (newMessages.length > 0) this.lastTimestamp = newMessages[newMessages.length - 1].created_at;
    } catch (err) {
      // silencieux : on retentera au prochain cycle
    }
  },

  async sendMessage() {
    const input = document.getElementById('chat-input');
    const content = input.value.trim();
    if (!content && !this.selectedFile) return;

    try {
      const sent = await Api.sendChatMessage(content, this.selectedFile);
      this.renderMessage(sent);
      this.lastTimestamp = sent.created_at;
    } catch (err) {
      alert(err.message);
    }

    input.value = '';
    this.selectedFile = null;
    document.getElementById('chat-media-input').value = '';
    document.getElementById('chat-attach-btn').classList.remove('has-file');
  },

  renderMessage({ username, content, created_at, media_url, media_type }) {
    const container = document.getElementById('chat-messages');
    const isMe = username === Auth.currentUser?.username;
    const time = new Date(created_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

    let mediaHtml = '';
    if (media_url) {
      mediaHtml = media_type === 'video'
        ? `<video src="${mediaUrl(media_url)}" controls class="chat-media"></video>`
        : `<img src="${mediaUrl(media_url)}" class="chat-media" />`;
    }

    const el = document.createElement('div');
    el.className = 'chat-msg';
    el.innerHTML = `
      <div class="chat-avatar">${username.slice(0, 2).toUpperCase()}</div>
      <div class="chat-msg-body">
        <div class="chat-msg-header">
          <span class="chat-username ${isMe ? 'me' : ''}">${this.escape(username)}</span>
          <span class="chat-time">${time}</span>
        </div>
        ${content ? `<div class="chat-content">${this.escape(content)}</div>` : ''}
        ${mediaHtml}
      </div>
    `;
    container.appendChild(el);
    container.scrollTop = container.scrollHeight;
  },

  escape(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  },

  disconnect() {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
  },
};
