// ============================================================
// Discussions privées : liste de conversations + chat 1-à-1,
// mises à jour par sondage périodique (polling), avec médias.
// ============================================================
const DM = {
  activeUserId: null,
  activeUsername: null,
  selectedFile: null,
  allUsers: [],
  pollInterval: null,
  lastTimestamp: null,

  init() {
    document.getElementById('dm-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this.send();
    });

    const attachBtn = document.getElementById('dm-attach-btn');
    const fileInput = document.getElementById('dm-media-input');
    attachBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', () => {
      this.selectedFile = fileInput.files[0] || null;
      document.getElementById('dm-attach-btn').classList.toggle('has-file', !!this.selectedFile);
    });

    document.getElementById('dm-new-btn').addEventListener('click', () => this.showUserPicker());
  },

  connect() {
    this.startPolling();
  },

  startPolling() {
    if (this.pollInterval) clearInterval(this.pollInterval);
    this.pollInterval = setInterval(() => this.poll(), 4000);
  },

  async poll() {
    // Rafraîchit toujours la liste des conversations (badges non-lus)
    this.loadConversations();

    if (!this.activeUserId) return;
    try {
      const newMessages = await Api.getConversation(this.activeUserId, this.lastTimestamp);
      newMessages.forEach((m) => this.renderMessage(m));
      if (newMessages.length > 0) this.lastTimestamp = newMessages[newMessages.length - 1].created_at;
    } catch (err) {
      // silencieux : on retentera au prochain cycle
    }
  },

  disconnect() {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
  },

  async loadConversations() {
    const conversations = await Api.getConversations();
    const list = document.getElementById('dm-conversations');
    list.innerHTML = '';

    if (conversations.length === 0) {
      list.innerHTML = '<p class="muted" style="padding:12px;">Aucune conversation. Clique sur ✉️ pour en démarrer une.</p>';
      return;
    }

    conversations.forEach((c) => {
      const item = document.createElement('div');
      item.className = 'dm-conversation-item' + (c.user_id === this.activeUserId ? ' active' : '');
      const initials = c.username.slice(0, 2).toUpperCase();
      item.innerHTML = `
        ${c.avatar_url
          ? `<img class="dm-avatar" src="${mediaUrl(c.avatar_url)}" />`
          : `<div class="dm-avatar dm-avatar-fallback">${initials}</div>`}
        <div class="dm-conv-info">
          <div class="dm-conv-name">${c.username}</div>
          <div class="dm-conv-last">${c.last_message ? c.last_message.slice(0, 40) : 'Média partagé'}</div>
        </div>
        ${c.unread > 0 ? `<span class="dm-unread-badge">${c.unread}</span>` : ''}
      `;
      item.addEventListener('click', () => this.openConversation(c.user_id, c.username));
      list.appendChild(item);
    });
  },

  async showUserPicker() {
    if (this.allUsers.length === 0) {
      this.allUsers = await Api.getUsersList();
    }
    const username = prompt(
      'Discuter avec qui ? Entre le nom d\'utilisateur :\n\n' + this.allUsers.map((u) => u.username).join(', ')
    );
    if (!username) return;
    const user = this.allUsers.find((u) => u.username.toLowerCase() === username.toLowerCase());
    if (!user) {
      alert('Utilisateur introuvable.');
      return;
    }
    this.openConversation(user.id, user.username);
  },

  async openConversation(userId, username) {
    this.activeUserId = userId;
    this.activeUsername = username;
    this.lastTimestamp = null;

    document.getElementById('dm-empty-state').classList.add('hidden');
    document.getElementById('dm-chat-area').classList.remove('hidden');
    document.getElementById('dm-chat-title').textContent = username;

    const history = await Api.getConversation(userId);
    const container = document.getElementById('dm-messages');
    container.innerHTML = '';
    history.forEach((m) => this.renderMessage(m));
    if (history.length > 0) this.lastTimestamp = history[history.length - 1].created_at;

    await this.loadConversations();
  },

  renderMessage(m) {
    const container = document.getElementById('dm-messages');
    const isMine = m.sender_id === Auth.currentUser.id;
    const time = new Date(m.created_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

    let mediaHtml = '';
    if (m.media_url) {
      mediaHtml = m.media_type === 'video'
        ? `<video src="${mediaUrl(m.media_url)}" controls class="dm-media"></video>`
        : `<img src="${mediaUrl(m.media_url)}" class="dm-media" />`;
    }

    const el = document.createElement('div');
    el.className = 'dm-bubble-row ' + (isMine ? 'mine' : 'theirs');
    el.innerHTML = `
      <div class="dm-bubble">
        ${m.content ? `<div>${this.escape(m.content)}</div>` : ''}
        ${mediaHtml}
        <span class="dm-bubble-time">${time}</span>
      </div>
    `;
    container.appendChild(el);
    container.scrollTop = container.scrollHeight;
  },

  async send() {
    const input = document.getElementById('dm-input');
    const content = input.value.trim();
    if ((!content && !this.selectedFile) || !this.activeUserId) return;

    try {
      const message = await Api.sendPrivateMessage(this.activeUserId, content, this.selectedFile);
      this.renderMessage(message);
      this.lastTimestamp = message.created_at;
      this.selectedFile = null;
      document.getElementById('dm-media-input').value = '';
      document.getElementById('dm-attach-btn').classList.remove('has-file');
      input.value = '';
      await this.loadConversations();
    } catch (err) {
      alert(err.message);
    }
  },

  escape(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  },
};
