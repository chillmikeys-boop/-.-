// ============================================================
// Fil de publications : les étudiants publient texte + médias
// ============================================================
const Feed = {
  selectedFile: null,

  init() {
    const fileInput = document.getElementById('post-media-input');
    const attachBtn = document.getElementById('post-attach-btn');
    const form = document.getElementById('post-form');
    const preview = document.getElementById('post-media-preview');

    attachBtn.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', () => {
      const file = fileInput.files[0];
      if (!file) return;
      this.selectedFile = file;
      preview.innerHTML = '';
      const url = URL.createObjectURL(file);
      const el = file.type.startsWith('video/')
        ? `<video src="${url}" controls></video>`
        : `<img src="${url}" />`;
      preview.innerHTML = `${el}<button type="button" id="post-media-remove">✕</button>`;
      preview.classList.remove('hidden');
      document.getElementById('post-media-remove').addEventListener('click', () => {
        this.selectedFile = null;
        fileInput.value = '';
        preview.classList.add('hidden');
        preview.innerHTML = '';
      });
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      this.publish();
    });
  },

  async publish() {
    const textarea = document.getElementById('post-content');
    const content = textarea.value.trim();
    if (!content && !this.selectedFile) return;

    try {
      await Api.createPost(content, this.selectedFile);
      textarea.value = '';
      this.selectedFile = null;
      document.getElementById('post-media-input').value = '';
      document.getElementById('post-media-preview').classList.add('hidden');
      document.getElementById('post-media-preview').innerHTML = '';
      await this.load();
    } catch (err) {
      alert(err.message);
    }
  },

  async load() {
    const posts = await Api.getPosts();
    const container = document.getElementById('feed-posts');
    container.innerHTML = '';

    if (posts.length === 0) {
      container.innerHTML = '<p class="muted">Aucune publication pour le moment. Sois le premier à partager quelque chose !</p>';
      return;
    }

    posts.forEach((post) => container.appendChild(this.renderPost(post)));
    if (window.lucide) lucide.createIcons();
  },

  renderPost(post) {
    const el = document.createElement('article');
    el.className = 'post-card';

    const initials = post.username.slice(0, 2).toUpperCase();
    const time = new Date(post.created_at).toLocaleString('fr-FR', {
      day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit',
    });

    let mediaHtml = '';
    if (post.media_url) {
      mediaHtml = post.media_type === 'video'
        ? `<video src="${mediaUrl(post.media_url)}" controls class="post-media"></video>`
        : `<img src="${mediaUrl(post.media_url)}" class="post-media" />`;
    }

    const isMine = Auth.currentUser && post.username === Auth.currentUser.username;

    el.innerHTML = `
      <div class="post-header">
        ${post.avatar_url
          ? `<img class="post-avatar" src="${mediaUrl(post.avatar_url)}" />`
          : `<div class="post-avatar post-avatar-fallback">${initials}</div>`}
        <div>
          <div class="post-username">${post.username}</div>
          <div class="post-time">${time}</div>
        </div>
        ${isMine ? `<button class="icon-btn small post-delete" title="Supprimer" data-id="${post.id}"><i data-lucide="trash-2"></i></button>` : ''}
      </div>
      ${post.content ? `<p class="post-content">${post.content}</p>` : ''}
      ${mediaHtml}
      <div class="post-actions">
        <button class="post-like-btn ${post.liked_by_me ? 'liked' : ''}" data-id="${post.id}">
          <i data-lucide="heart"></i> <span>${post.likes_count}</span>
        </button>
      </div>
    `;

    el.querySelector('.post-like-btn').addEventListener('click', (e) => this.toggleLike(e.currentTarget));
    const delBtn = el.querySelector('.post-delete');
    if (delBtn) delBtn.addEventListener('click', (e) => this.deletePost(e.currentTarget.dataset.id));

    return el;
  },

  async toggleLike(btn) {
    const id = btn.dataset.id;
    const { liked } = await Api.likePost(id);
    const countEl = btn.querySelector('span');
    let count = parseInt(countEl.textContent, 10);
    countEl.textContent = liked ? count + 1 : count - 1;
    btn.classList.toggle('liked', liked);
  },

  async deletePost(id) {
    if (!confirm('Supprimer cette publication ?')) return;
    await Api.deletePost(id);
    await this.load();
  },
};
