// ============================================================
// Client API — communique avec les Netlify Functions.
// Chemins relatifs : tout est servi depuis le même domaine Netlify,
// pas besoin de configurer d'URL de backend séparée.
// ============================================================
const API_BASE = '/api';

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(',')[1]); // retire le préfixe data:...;base64,
    reader.onerror = () => reject(new Error("Erreur de lecture du fichier."));
    reader.readAsDataURL(file);
  });
}

function mediaUrl(path) {
  if (!path) return '';
  return path; // chemin déjà relatif, ex: /api/media/xxxx.png
}

const Api = {
  token: null,

  setToken(token) {
    this.token = token;
    if (token) localStorage.setItem('dp_token', token);
    else localStorage.removeItem('dp_token');
  },

  loadToken() {
    this.token = localStorage.getItem('dp_token');
    return this.token;
  },

  async request(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    if (this.token) headers['Authorization'] = `Bearer ${this.token}`;

    const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
    const data = await res.json().catch(() => ({}));

    if (!res.ok) throw new Error(data.error || 'Erreur réseau.');
    return data;
  },

  // ---- Auth ----
  register(username, email, password) {
    return this.request('/auth/register', { method: 'POST', body: JSON.stringify({ username, email, password }) });
  },
  login(username, password) {
    return this.request('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) });
  },
  me() {
    return this.request('/auth/me');
  },
  async uploadAvatar(file) {
    const dataBase64 = await fileToBase64(file);
    return this.request('/auth/avatar', {
      method: 'POST',
      body: JSON.stringify({ dataBase64, contentType: file.type }),
    });
  },

  // ---- Cours ----
  getCourses() {
    return this.request('/courses');
  },
  getExercises(courseId) {
    return this.request(`/courses/${courseId}/exercises`);
  },
  submitExercise(exerciseId, code, output) {
    return this.request(`/courses/exercises/${exerciseId}/submit`, {
      method: 'POST',
      body: JSON.stringify({ code, output }),
    });
  },
  getLeaderboard() {
    return this.request('/courses/leaderboard/top');
  },

  // ---- Fil de publications ----
  getPosts() {
    return this.request('/posts');
  },
  async createPost(content, file) {
    let mediaBase64 = null;
    let mediaContentType = null;
    if (file) {
      mediaBase64 = await fileToBase64(file);
      mediaContentType = file.type;
    }
    return this.request('/posts', {
      method: 'POST',
      body: JSON.stringify({ content, mediaBase64, mediaContentType }),
    });
  },
  likePost(postId) {
    return this.request(`/posts/${postId}/like`, { method: 'POST' });
  },
  deletePost(postId) {
    return this.request(`/posts/${postId}`, { method: 'DELETE' });
  },

  // ---- Chat global ----
  getChatMessages(since) {
    return this.request(`/chat${since ? `?since=${encodeURIComponent(since)}` : ''}`);
  },
  async sendChatMessage(content, file) {
    let mediaBase64 = null;
    let mediaContentType = null;
    if (file) {
      mediaBase64 = await fileToBase64(file);
      mediaContentType = file.type;
    }
    return this.request('/chat', {
      method: 'POST',
      body: JSON.stringify({ content, mediaBase64, mediaContentType }),
    });
  },

  // ---- Discussions privées ----
  getUsersList() {
    return this.request('/messages/users');
  },
  getConversations() {
    return this.request('/messages/conversations');
  },
  getConversation(userId, since) {
    return this.request(`/messages/${userId}${since ? `?since=${encodeURIComponent(since)}` : ''}`);
  },
  async sendPrivateMessage(userId, content, file) {
    let mediaBase64 = null;
    let mediaContentType = null;
    if (file) {
      mediaBase64 = await fileToBase64(file);
      mediaContentType = file.type;
    }
    return this.request(`/messages/${userId}`, {
      method: 'POST',
      body: JSON.stringify({ content, mediaBase64, mediaContentType }),
    });
  },
};
