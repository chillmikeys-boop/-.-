// ============================================================
// Photo de profil : sélection depuis la galerie et upload
// ============================================================
const Profile = {
  init() {
    const input = document.getElementById('avatar-input');
    const trigger = document.getElementById('avatar-trigger');

    trigger.addEventListener('click', () => input.click());

    input.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;

      if (!file.type.startsWith('image/')) {
        alert('Merci de choisir une image.');
        return;
      }

      try {
        const { avatar_url } = await Api.uploadAvatar(file);
        this.applyAvatar(avatar_url);
      } catch (err) {
        alert(err.message);
      } finally {
        input.value = '';
      }
    });
  },

  applyAvatar(avatarUrl) {
    const url = mediaUrl(avatarUrl);
    document.querySelectorAll('.avatar-img').forEach((img) => {
      img.src = url;
      img.classList.remove('hidden');
    });
    document.querySelectorAll('.avatar-fallback').forEach((el) => el.classList.add('hidden'));
    if (Auth.currentUser) Auth.currentUser.avatar_url = avatarUrl;
  },

  loadInitial(user) {
    if (user.avatar_url) {
      this.applyAvatar(user.avatar_url);
    } else {
      const initials = (user.username || '?').slice(0, 2).toUpperCase();
      document.querySelectorAll('.avatar-fallback').forEach((el) => (el.textContent = initials));
    }
  },
};
