// ============================================================
// Cours, exercices (autonomes, sans terminal), classement
// ============================================================
const Courses = {
  list: [],

  async loadCourses() {
    this.list = await Api.getCourses();
    this.renderCourseGrid('courses-list');
    this.renderCourseGrid('dashboard-courses', true);
  },

  renderCourseGrid(containerId, limitFirst4 = false) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';
    const items = limitFirst4 ? this.list.slice(0, 4) : this.list;

    items.forEach((course) => {
      const pct = course.progress.total > 0
        ? Math.round((course.progress.termines / course.progress.total) * 100)
        : 0;

      const card = document.createElement('div');
      card.className = 'course-card';
      card.innerHTML = `
        <span class="badge">${course.language} · ${course.level}</span>
        <h4>${course.title}</h4>
        <p>${course.description}</p>
        <div class="progress-bar"><div class="progress-bar-fill" style="width:${pct}%"></div></div>
        <p class="muted" style="margin-top:6px;">${course.progress.termines}/${course.progress.total} exercices — ${pct}%</p>
      `;
      card.addEventListener('click', () => this.openCourse(course));
      container.appendChild(card);
    });
  },

  async openCourse(course) {
    App.switchView('courses');
    const exercises = await Api.getExercises(course.id);

    document.getElementById('courses-list').classList.add('hidden');
    const detail = document.getElementById('course-detail');
    detail.classList.remove('hidden');
    document.getElementById('course-detail-title').textContent = course.title;

    const list = document.getElementById('exercises-list');
    list.innerHTML = '';

    if (exercises.length === 0) {
      list.innerHTML = '<p class="muted">Aucun exercice disponible pour ce cours pour le moment.</p>';
    } else {
      exercises.forEach((ex) => list.appendChild(this.renderExercise(ex)));
    }

    if (window.lucide) lucide.createIcons();

    document.getElementById('back-to-courses').onclick = () => {
      detail.classList.add('hidden');
      document.getElementById('courses-list').classList.remove('hidden');
    };
  },

  renderExercise(exercise) {
    const el = document.createElement('div');
    el.className = 'exercise-card';
    const done = exercise.status === 'termine';

    el.innerHTML = `
      <div class="exercise-card-header">
        <span class="points-badge">${done ? '✔ Terminé — ' : ''}+${exercise.points} pts</span>
        <h4>${exercise.title}</h4>
      </div>
      <p>${exercise.instructions}</p>
      ${exercise.starter_code ? `<p class="muted">Code de départ :</p><pre>${exercise.starter_code}</pre>` : ''}
      ${exercise.expected_output ? `<p class="muted">Résultat attendu :</p><pre>${exercise.expected_output}</pre>` : ''}

      <label class="exercise-label">Ton code :</label>
      <textarea class="exercise-code-input" rows="4" placeholder="Écris ta solution ici...">${exercise.submitted_code || exercise.starter_code || ''}</textarea>

      <label class="exercise-label">Résultat obtenu en l'exécutant sur ta machine :</label>
      <textarea class="exercise-output-input" rows="2" placeholder="Colle ici la sortie obtenue..."></textarea>

      <button class="btn-primary exercise-submit-btn" style="width:auto; padding:8px 20px; margin-top:10px;">Soumettre ma solution</button>
      <div class="submit-result-container"></div>
    `;

    el.querySelector('.exercise-submit-btn').addEventListener('click', () => this.submit(exercise, el));
    return el;
  },

  async submit(exercise, el) {
    const code = el.querySelector('.exercise-code-input').value;
    const output = el.querySelector('.exercise-output-input').value;
    const resultBox = el.querySelector('.submit-result-container');

    try {
      const result = await Api.submitExercise(exercise.id, code, output);
      if (result.correct) {
        resultBox.innerHTML = `<div class="submit-result success">✔ Exercice réussi ! +${result.score} points</div>`;
      } else {
        resultBox.innerHTML = `<div class="submit-result fail">✖ Pas encore correct, réessaie !</div>`;
      }
      await App.refreshStats();
    } catch (err) {
      resultBox.innerHTML = `<div class="submit-result fail">${err.message}</div>`;
    }
  },

  async loadLeaderboard() {
    const rows = await Api.getLeaderboard();
    const body = document.getElementById('leaderboard-body');
    body.innerHTML = '';
    rows.forEach((row, i) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>#${i + 1}</td><td>${row.username}</td><td>${row.total_points}</td>`;
      body.appendChild(tr);
    });
  },
};
