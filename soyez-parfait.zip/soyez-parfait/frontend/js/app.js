// ============================================================
// Application principale : navigation, initialisation, stats
// ============================================================
const App = {
  async init() {
    Auth.init();
    lucide.createIcons();

    const loggedIn = await Auth.tryAutoLogin();
    if (loggedIn) {
      await this.start();
    }
  },

  async start() {
    document.getElementById('auth-screen').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
    document.getElementById('user-badge').textContent = Auth.currentUser.username;

    this.initNav();
    Chat.init();
    Profile.init();
    Feed.init();
    DM.init();
    Chat.connect();
    DM.connect();

    const me = await Api.me();
    Profile.loadInitial(me);

    await Courses.loadCourses();
    await Courses.loadLeaderboard();
    await Feed.load();
    await DM.loadConversations();
    await this.refreshStats();

    lucide.createIcons();
  },

  initNav() {
    document.querySelectorAll('.nav-btn').forEach((btn) => {
      btn.addEventListener('click', () => this.switchView(btn.dataset.view));
    });
  },

  switchView(view) {
    document.querySelectorAll('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
    document.querySelectorAll('.view').forEach((v) => v.classList.remove('active'));
    document.getElementById(`view-${view}`).classList.add('active');

    if (view === 'leaderboard') Courses.loadLeaderboard();
    if (view === 'feed') Feed.load();
    if (view === 'dm') DM.loadConversations();
  },

  async refreshStats() {
    try {
      const totalTermines = Courses.list.reduce((sum, c) => sum + c.progress.termines, 0);
      document.getElementById('stat-completed').textContent = totalTermines;

      const leaderboard = await Api.getLeaderboard();
      const mine = leaderboard.find((r) => r.username === Auth.currentUser.username);
      document.getElementById('stat-points').textContent = mine ? mine.total_points : 0;
    } catch (err) {
      console.warn('Impossible de charger les statistiques :', err.message);
    }
  },
};

document.addEventListener('DOMContentLoaded', () => App.init());
