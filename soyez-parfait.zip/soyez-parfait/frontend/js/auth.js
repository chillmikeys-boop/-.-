// ============================================================
// Authentification : gère les formulaires login / register
// ============================================================
const Auth = {
  currentUser: null,

  init() {
    document.querySelectorAll('.tab-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
        document.querySelectorAll('.auth-form').forEach((f) => f.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(`${btn.dataset.tab}-form`).classList.add('active');
      });
    });

    document.getElementById('login-form').addEventListener('submit', (e) => this.handleLogin(e));
    document.getElementById('register-form').addEventListener('submit', (e) => this.handleRegister(e));
    document.getElementById('logout-btn').addEventListener('click', () => this.logout());
  },

  async handleLogin(e) {
    e.preventDefault();
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
    const errorEl = document.getElementById('login-error');
    errorEl.textContent = '';

    try {
      const { user, token } = await Api.login(username, password);
      Api.setToken(token);
      this.currentUser = user;
      await App.start();
    } catch (err) {
      errorEl.textContent = err.message;
    }
  },

  async handleRegister(e) {
    e.preventDefault();
    const username = document.getElementById('register-username').value.trim();
    const email = document.getElementById('register-email').value.trim();
    const password = document.getElementById('register-password').value;
    const errorEl = document.getElementById('register-error');
    errorEl.textContent = '';

    try {
      const { user, token } = await Api.register(username, email, password);
      Api.setToken(token);
      this.currentUser = user;
      await App.start();
    } catch (err) {
      errorEl.textContent = err.message;
    }
  },

  async tryAutoLogin() {
    const token = Api.loadToken();
    if (!token) return false;
    try {
      const user = await Api.me();
      this.currentUser = user;
      return true;
    } catch (err) {
      Api.setToken(null);
      return false;
    }
  },

  logout() {
    Api.setToken(null);
    this.currentUser = null;
    Chat.disconnect();
    DM.disconnect();
    document.getElementById('app').classList.add('hidden');
    document.getElementById('auth-screen').classList.remove('hidden');
  },
};
