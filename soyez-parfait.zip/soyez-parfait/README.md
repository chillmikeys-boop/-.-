# 🔥 SOYEZ PARFAIT — *BY 𝐌𝐑. 𝐋𝐔𝐂𝐈𝐅𝐄𝐑 𝐌𝐎𝐑𝐍𝐈𝐍𝐆𝐒𝐓𝐀𝐑 𝐒𝐀𝐃𝐄𝐔𝐒.*

Plateforme communautaire d'apprentissage du code : cours interactifs, fil de
publications avec médias, chat global et messages privés, photo de profil.

**100% Netlify** : frontend + API (Netlify Functions) + base de données
(Netlify DB) + stockage des médias (Netlify Blobs). Un seul compte, un seul
déploiement, rien d'autre à héberger.

Design : sombre, inspiré de Termux et VS Code.

---

## 📁 Structure du projet

```
soyez-parfait/
├── netlify.toml               # Config : build, routage API → functions, fallback SPA
├── package.json                # Dépendances des fonctions (racine du repo)
├── db/schema.sql               # Schéma PostgreSQL à exécuter une fois sur Netlify DB
├── netlify/functions/
│   ├── auth.js                 # /api/auth/* : inscription, connexion, profil, avatar
│   ├── courses.js              # /api/courses/* : cours, exercices, classement
│   ├── posts.js                # /api/posts/* : fil de publications + médias + likes
│   ├── messages.js              # /api/messages/* : discussions privées + médias
│   ├── chat.js                 # /api/chat/* : chat global (sondage périodique)
│   ├── media.js                 # /api/media/:clé : sert les fichiers (Netlify Blobs)
│   └── lib/                     # db.js, auth.js (JWT), response.js, blobs.js
└── frontend/
    ├── index.html
    ├── css/style.css
    └── js/
        ├── api.js               # Client API (chemins relatifs /api/...)
        ├── auth.js, courses.js, chat.js, dm.js, feed.js, profile.js, app.js
```

⚠️ **Important sur le "temps réel"** : les Netlify Functions sont sans état et
ne maintiennent pas de connexion persistante (pas de WebSocket). Le chat global
et les messages privés fonctionnent donc par **sondage automatique** (nouvelles
requêtes toutes les 3-4 secondes) plutôt qu'en push instantané. C'est invisible
à l'usage — juste un léger délai de quelques secondes entre l'envoi et la
réception chez l'autre personne.

---

## 🚀 Déploiement — 100% Netlify, gratuitement

### 1. Pousse le projet sur GitHub (ou GitLab/Bitbucket)
Netlify se connecte à ton dépôt Git pour déployer et redéployer automatiquement
à chaque `git push`.

### 2. Crée le site sur Netlify
1. Va sur **app.netlify.com** → *Add new site* → *Import an existing project*
2. Connecte ton dépôt
3. Netlify détecte automatiquement `netlify.toml` (publish = `frontend`,
   functions = `netlify/functions`, build command = `npm install`)
4. Clique sur *Deploy*

### 3. Active Netlify DB (base de données, intégrée)
1. Dans le tableau de bord du site → onglet **Databases** (ou **Integrations**)
2. Clique sur **Enable Netlify DB** / *Create database* — c'est provisionné
   instantanément (propulsé par Neon en coulisses, mais tout se pilote depuis
   Netlify, pas besoin de créer un compte ailleurs)
3. Une variable d'environnement `NETLIFY_DATABASE_URL` est injectée automatiquement
   dans tes fonctions — rien à configurer à la main
4. Ouvre l'onglet **SQL / Query** de la base et colle le contenu de
   `db/schema.sql`, puis exécute-le (une seule fois)

⚠️ Une base créée sans être "réclamée" est temporaire (7 jours d'essai). Clique
sur **"Claim database" / "Connect to Neon account"** dans le tableau de bord
(gratuit, ça prend 30 secondes) pour la rendre permanente.

### 4. Ajoute la variable JWT_SECRET
1. Site settings → **Environment variables** → *Add a variable*
2. `JWT_SECRET` = une longue chaîne aléatoire (ex : générée avec `openssl rand -hex 32`)
3. Redéploie le site (Deploys → *Trigger deploy*) pour que la variable soit prise en compte

### 5. Netlify Blobs (stockage des médias)
Rien à faire : Netlify Blobs est activé automatiquement pour chaque site, aucune
configuration ni compte supplémentaire nécessaire. Les avatars et médias postés
sont stockés dedans et servis via `/api/media/...`.

### 6. C'est en ligne 🎉
Ton site est accessible à l'URL fournie par Netlify (ex :
`https://ton-site.netlify.app`). Inscris-toi, tout devrait fonctionner :
cours, fil, chat, messages privés, photo de profil.

---

## 🔧 Développement local

```bash
npm install -g netlify-cli
netlify login
netlify link          # relie ce dossier à ton site Netlify
netlify dev           # lance frontend + functions + DB en local sur http://localhost:8888
```

`netlify dev` reproduit fidèlement l'environnement de production (functions,
redirects, variables d'environnement, Blobs) — pas besoin de configuration
séparée pour tester en local.

---

## ✨ Fonctionnalités

| Catégorie | Détail |
|---|---|
| Comptes | Inscription/connexion sécurisées (JWT + bcrypt) |
| Cours | Cours par langage/niveau, exercices avec soumission de code + sortie, points, classement |
| Photo de profil | Choix d'une image depuis la galerie |
| Fil de publications | Texte + image/vidéo, likes, suppression de ses propres posts |
| Chat global | Discussion entre tous les connectés (sondage ~3s), historique, partage de médias |
| Discussions privées | Messages 1-à-1 (sondage ~4s), historique, non-lus, partage de médias |

---

## 🛣️ Limites de cette version (et comment les lever plus tard)

- **Pas de terminal Linux isolé par étudiant** : nécessiterait Docker, que les
  Netlify Functions ne peuvent pas piloter. Si ce module redevient nécessaire,
  il faudrait un hébergeur avec accès Docker (VPS, ou Oracle Cloud "Always
  Free") en plus de Netlify — demande-le si tu veux qu'on l'ajoute.
- **Chat/DM par sondage plutôt qu'en push instantané** : léger délai de
  quelques secondes, mais reste 100% dans l'écosystème Netlify.
- **Fichiers limités à 15 Mo** (limite raisonnable pour rester dans le plan
  gratuit de Netlify Blobs/Functions).
