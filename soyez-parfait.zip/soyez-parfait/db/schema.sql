-- ============================================================
-- Devenez parfait — par l'intervention du mec parfait
-- Schéma PostgreSQL (Netlify DB, propulsé par Neon)
-- À exécuter une fois via l'éditeur SQL de Netlify DB / Neon
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    avatar_url VARCHAR(255) DEFAULT NULL,
    role VARCHAR(20) DEFAULT 'student', -- student | admin | teacher
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS courses (
    id SERIAL PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    language VARCHAR(30) NOT NULL, -- bash, python, javascript, c, cpp, git
    level VARCHAR(20) DEFAULT 'debutant', -- debutant | intermediaire | avance
    icon VARCHAR(50) DEFAULT 'terminal',
    position INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS exercises (
    id SERIAL PRIMARY KEY,
    course_id INT REFERENCES courses(id) ON DELETE CASCADE,
    title VARCHAR(150) NOT NULL,
    instructions TEXT NOT NULL,
    starter_code TEXT DEFAULT '',
    expected_output TEXT DEFAULT '',
    points INT DEFAULT 10,
    position INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS progress (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    exercise_id INT REFERENCES exercises(id) ON DELETE CASCADE,
    status VARCHAR(20) DEFAULT 'non_commence', -- non_commence | en_cours | termine
    score INT DEFAULT 0,
    submitted_code TEXT DEFAULT '',
    completed_at TIMESTAMP DEFAULT NULL,
    UNIQUE(user_id, exercise_id)
);

CREATE TABLE IF NOT EXISTS scores (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    total_points INT DEFAULT 0,
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id)
);

CREATE TABLE IF NOT EXISTS certificates (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    course_id INT REFERENCES courses(id) ON DELETE CASCADE,
    issued_at TIMESTAMP DEFAULT NOW(),
    certificate_code VARCHAR(50) UNIQUE NOT NULL
);

-- Chat global
CREATE TABLE IF NOT EXISTS messages (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    username VARCHAR(50) NOT NULL,
    content TEXT NOT NULL,
    media_url VARCHAR(500) DEFAULT NULL,
    media_type VARCHAR(20) DEFAULT NULL, -- image | video | null
    created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);

-- Publications (fil d'actualité) avec média (image/vidéo)
CREATE TABLE IF NOT EXISTS posts (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    content TEXT DEFAULT '',
    media_url VARCHAR(500) DEFAULT NULL,
    media_type VARCHAR(20) DEFAULT NULL, -- image | video | null
    created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts(created_at);

CREATE TABLE IF NOT EXISTS post_likes (
    id SERIAL PRIMARY KEY,
    post_id INT REFERENCES posts(id) ON DELETE CASCADE,
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE(post_id, user_id)
);

-- Discussions privées (messages 1-à-1) avec partage de média
CREATE TABLE IF NOT EXISTS private_messages (
    id SERIAL PRIMARY KEY,
    sender_id INT REFERENCES users(id) ON DELETE CASCADE,
    receiver_id INT REFERENCES users(id) ON DELETE CASCADE,
    content TEXT DEFAULT '',
    media_url VARCHAR(500) DEFAULT NULL,
    media_type VARCHAR(20) DEFAULT NULL, -- image | video | null
    read_at TIMESTAMP DEFAULT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_pm_pair ON private_messages(sender_id, receiver_id, created_at);

-- Quelques cours de départ
INSERT INTO courses (title, description, language, level, icon, position) VALUES
('Introduction au Terminal Linux', 'Apprends les commandes de base : ls, cd, mkdir, rm, cat...', 'bash', 'debutant', 'terminal', 1),
('Python pour débutants', 'Variables, boucles, fonctions et scripts Python.', 'python', 'debutant', 'code', 2),
('JavaScript moderne', 'ES6+, fonctions, tableaux, async/await.', 'javascript', 'intermediaire', 'code', 3),
('C - les fondamentaux', 'Pointeurs, mémoire, compilation avec gcc.', 'c', 'intermediaire', 'cpu', 4),
('Git & versioning', 'commit, branch, merge, push, pull.', 'git', 'debutant', 'git-branch', 5)
ON CONFLICT DO NOTHING;

-- Quelques exercices de départ
INSERT INTO exercises (course_id, title, instructions, starter_code, expected_output, points, position) VALUES
(1, 'Lister les fichiers', 'Utilise la commande `ls -la` pour afficher le contenu du dossier courant.', '', '', 10, 1),
(1, 'Créer un dossier', 'Crée un dossier nommé "projet" avec `mkdir projet`, puis affiche-le avec `ls`.', '', '', 10, 2),
(2, 'Bonjour Python', 'Écris un script qui affiche "Bonjour depuis Devenez parfait !" avec print().', 'print("Bonjour depuis Devenez parfait !")', 'Bonjour depuis Devenez parfait !', 10, 1),
(3, 'Bonjour JavaScript', 'Écris un script Node.js qui affiche "Bonjour JS" avec console.log().', 'console.log("Bonjour JS");', 'Bonjour JS', 10, 1),
(4, 'Compiler un programme C', 'Écris un programme C qui affiche "Bonjour C" et compile-le avec gcc.', '#include <stdio.h>
int main() {
  printf("Bonjour C\n");
  return 0;
}', 'Bonjour C', 15, 1)
ON CONFLICT DO NOTHING;
